#include <bits/stdc++.h>
#define rn(x) (((long)rand() << 15) | rand()) % (x) + 1
#define x first
#define y second
using namespace std;
vector<pair<int, int> > kg;
vector<int> label;
int main()
{
    srand(time(NULL));
    for(int te = 1; te < 4; te++) {
        kg.clear();
        label.clear();
        string ins = "./3/test" + to_string(te) + ".in";
        FILE *in = fopen(ins.c_str(), "r");
        int n, k, f;
        n = rn(900);
        k = rn(60);
        int alpha = rn((n - k) / 2);
        f = rn(n * (n - 1) / 2);
        fprintf(in, "%d %d %d\n", k, n, f);
        for(int i=0; i<=n; i++) label.push_back(i);
        random_shuffle(label.begin() + 1, label.end());
        for(int i=1; i<=k + alpha; i++)
            for(int j=i + 1; j<=k + alpha; j++)
                kg.push_back({i, j});
        for(int i=1; i<=n; i++)
            for(int j=i + 1; j<=n; j++)
                if(kg.size() < f) kg.push_back({i, j});
        sort(kg.begin(), kg.end());
        kg.erase(unique(kg.begin(), kg.end()), kg.end());
        random_shuffle(kg.begin(), kg.end());
        for(auto t : kg) {
            if(rn(2) - 1) fprintf(in, "%d %d\n", label[t.x], label[t.y]);
            else fprintf(in, "%d %d\n", label[t.y], label[t.x]);
        }
        fclose(in);
    }
}
